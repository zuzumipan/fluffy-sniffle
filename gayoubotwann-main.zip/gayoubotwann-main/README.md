<p align="center">
    <a href="https://pyrogram.org">
        <img src="https://docs.pyrogram.org/_static/pyrogram.png" alt="Pyrogram" width="128">
    </a>
    <br>
    <b>Telegram MTProto API Framework for Python</b>
    <br>
    <a href="https://pyrogram.org">
        Homepage
    </a>
    •
    <a href="https://docs.pyrogram.org">
        Documentation
    </a>
    •
    <a href="https://docs.pyrogram.org/releases">
        Releases
    </a>
    •
    <a href="https://t.me/pyrogram">
        News
    </a>
</p>

## Pyrogram
> This Pyrogram code, Recode With BY <a href="https://t.me/wannoffc08">WannOfficial</a>
___________________________________________
## Commad Installer Userbot
```
apt update && apt upgrade -y
```
```
git clone https://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@github.com/HafizBotz/gayoubotwann && cd gayoubotwann 
```
```
screen -S gayoubotwann
```
```
bash installmodule.sh
```
```
cp sample.env .env && nano .env
```
```
bash start
```
