curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt-get install -y nodejs
apt install python3-pip -y
apt install ffmpeg -y
pip3 install -r requirements.txt
