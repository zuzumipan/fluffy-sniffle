__MODULE__ = "ᴄᴏʟᴏɴɢ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Colong

perintah : <code>{0}colong</code>
    untuk mengambil media/vidio yang 1x lihat</b></blockquote>
"""
